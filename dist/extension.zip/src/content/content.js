// Lembrete visual no YouTube
const banner = document.createElement("div");
banner.textContent = "⚠️ Lembre-se do seu tempo de foco!";
banner.style.position = "fixed";
banner.style.bottom = "10px";
banner.style.right = "10px";
banner.style.background = "yellow";
banner.style.padding = "10px";
banner.style.zIndex = 9999;
document.body.appendChild(banner);
